﻿# -*- coding: utf-8 -*-
import scrapy
import sys
reload(sys)
#python默认环境编码时ascii
sys.setdefaultencoding("utf-8")
import re
from scrapy.http import Request
from thirdDemo.items import ThirddemoItem

class TaobaoSpider(scrapy.Spider):
    name = 'taobao'
    allowed_domains = ['taobao.com']
#    allowed_domains = []
    start_urls = ['http://taobao.com/']

    def parse(self, response):
        key = '小吃'
        for i in range(0, 2):
            url = 'https://s.taobao.com/search?q=' + str(key) + '&s=' + str(44*i)
#            print url
            yield Request(url=url, callback=self.page)
        pass

    def page(self, response):
	    body = response.body.decode('utf-8','ignore')
	    pattam_id = '"nid":"(.*?)"'
 	    all_id = re.compile(pattam_id).findall(body)
#	    print all_id
       	    for i in range(0, len(all_id)):
#		print i
                this_id = all_id[i]
#		print this_id
                url = 'https://item.taobao.com/item.htm?id=' + str(this_id)
                yield Request(url=url, callback=self.next)
                pass
            pass
        
    def next(self,response):
#        print(response.url)
	url = response.url
	pattam_url = 'https://(.*?).com'
	subdomain = re.compile(pattam_url).findall(url)
#	print subdomain
	if subdomain[0] != 'item.taobao':
		subSelector = response.xpath('//div[@class="tb-detail-hd"]')
		for sub in subSelector:
			title = sub.xpath('.//h1/text()').extract()[0]
#		title = response.xpath("//div[@class='tb-detail-hd']/h1/text()").extract()
		pass
	else:
		subSelector = response.xpath('//h3[@class="tb-main-title"]')
		for sub in subSelector:
			title = sub.xpath('./@data-title').extract()[0]
#		title = response.xpath("//h3[@class='tb-main-title']/@data-title").extract()
		pass
	self.num = self.num + 1;
	print title
	pass
        
